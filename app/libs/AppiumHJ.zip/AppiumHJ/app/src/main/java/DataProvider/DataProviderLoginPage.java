package DataProvider;

import Utility.ExcelHandler;

import java.io.File;
import java.io.FileInputStream;

import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import Listerners.ConfigFileReader;

public class DataProviderLoginPage {

	public static ConfigFileReader 	obj_config = new ConfigFileReader();;

	/*@Parameters({"excelLoc","excelSheetLogin"})
	@DataProvider
	public static Object[][] getTableData(ITestContext context) throws Exception
	{
		String excelLocation=null,excelSheetName=null;
		excelLocation=context.getSuite().getParameter("excelLoc");
    	System.out.println("located Excel at " +excelLocation);
    	excelSheetName=context.getSuite().getParameter("excelSheetLogin");
    	System.out.println("located sheet : "+excelSheetName);
		//FileInputStream f = new FileInputStream(new File(excelLocation));
    	File location=new File(excelLocation);
    	System.out.println("File Located at :"+location.getAbsolutePath());
    	FileInputStream fin=new FileInputStream(location);
		//XSSFWorkbook workbook=null;
		*//*try {
			 workbook = new XSSFWorkbook(fin);
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		String[] sheetNames=new String[workbook.getNumberOfSheets()] ;
		System.out.println("excelhandler"+sheetNames.length);
		XSSFSheet[] sheetData=new XSSFSheet[workbook.getNumberOfSheets()] ;
*//*
		ExcelHandler excel=null;
		try {
			excel = new ExcelHandler(fin);
		}catch (Exception e)
		{
			e.printStackTrace();
		}
    	System.out.println("Excel"+excel);
    	excel.selectSheet(excelSheetName);
		System.out.println("selected sheet name"+excel.selectedSheetName());

    	int i,rowCount,columnCount;
    	rowCount=excel.getRowCount();

    	System.out.println("row count is : "+rowCount);
    	
		String email;
		String expectedMsg;
    	
    	email=excel.getCellData(5, 4).getStringCellValue();		// invalid format email
    	expectedMsg=excel.getCellData(4,4).getStringCellValue();		// valid format but unregistered email
		//email[2]=excel.getCellData(4,3).getContents();		// valid format but unregistered email

    *//*	password[0]=excel.getCellData(5, 5).getContents();		// incorrect password
    	password[1]=excel.getCellData(5,7).getContents();		// correct password
    *//**//*
    	for(i=2;i<=rowCount;i++)
    		expectedMsg[i-2]=excel.getCellData(3, i).getContents();
    	*//*
    	return new Object[][]{{email,expectedMsg}};
	}*/


	//@Parameters({"excelLoc","excelSheetLogin"})
	@DataProvider
	public static Object[][] invalidData(ITestContext context) throws Exception {
		String excelLocation=null,excelSheetName=null;
		excelLocation=obj_config.getExcel();
		System.out.println("located Excel at " +excelLocation);
		excelSheetName= obj_config.getSheetName();
		System.out.println("located sheet : "+excelSheetName);
		File location=new File(excelLocation);
		System.out.println("File Located at :"+location.getAbsolutePath());
		FileInputStream fin=new FileInputStream(location);

		ExcelHandler excel=null;
		try {
			excel = new ExcelHandler(fin);
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Excel"+excel);
		excel.selectSheet(obj_config.getSheetName());
		System.out.println("selected sheet name"+excel.selectedSheetName());

		int i,rowCount,columnCount;
		rowCount=excel.getRowCount();
		System.out.println("row count is : "+rowCount);
		String tcId,tcName,expectedMsg;
		double email;
		email = excel.getCellData(6,3).getNumericCellValue();        // invalid format email
		expectedMsg = excel.getCellData(5, 3).getStringCellValue();
        tcId=excel.getCellData(1,3).getStringCellValue();
        tcName=excel.getCellData(2,3).getStringCellValue();
		return new Object[][]{{tcId,tcName,email,expectedMsg}};
	}


/*
	@Parameters({"excelLoc","excelSheetLogin"})
	@DataProvider
	public static Object[][] getValidTableData(ITestContext context) throws Exception
	{
	
		
		String excelLocation=null,excelSheetName=null;
		excelLocation=context.getCurrentXmlTest().getParameter("excelLoc");
    	System.out.println("located Excel at " +excelLocation);
    	excelSheetName=context.getCurrentXmlTest().getParameter("excelSheetLogin");
    	System.out.println("located sheet : "+excelSheetName);
    	File location=new File(excelLocation);
    	ExcelHandler excel=new ExcelHandler(location);
    	excel.selectSheet(excelSheetName);
    
    	String email[]=new String[2];
		String password[]=new String[2];
		String expectedMsg[]=new String[2];
		
		//valid but not verified email and password
		email[0]=excel.getCellData(5, 6).getStringCellValue();
		//password[0]=excel.getCellData(5, 7).getContents();
		
		//valid and verified email and password
		email[1]=excel.getCellData(5, 9).getStringCellValue().split("\n")[0];
		//password[1]=excel.getCellData(5, 9).getContents().split("\n")[1];
		
		expectedMsg[0]=excel.getCellData(4,7).getStringCellValue();
		expectedMsg[1]=excel.getCellData(4, 8).getStringCellValue();
		
		return new Object[][]{{email,password,expectedMsg}};
	
	}*/
}
