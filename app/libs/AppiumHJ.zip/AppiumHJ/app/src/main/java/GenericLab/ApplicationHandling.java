package GenericLab;

import android.opengl.Visibility;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeSuite;
import org.openqa.selenium.By;


import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import Listerners.ConfigFileReader;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import static GenericLab.ActionDrivers.visibilityOfElement;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class ApplicationHandling {

    public static AndroidDriver driver;
    public static ExtentTest test;
    public static ExtentReports extent;
    //public static boolean visibilityOfElement;
    public static ConfigFileReader cfg;

    public  ApplicationHandling()
    {
         cfg = new ConfigFileReader();
        System.out.println("Inside application handling constructor");
        Date date=new Date();
        SimpleDateFormat dateFormatFolder = new SimpleDateFormat("dd_MMM_yyyy");
        File ResultDir = new File(System.getProperty("user.dir")+File.separator+"/FrameworkReports/"+dateFormatFolder.format(date));  // Defining Directory/Folder Name
        if (!ResultDir.exists()){  // Checks that Directory/Folder Doesn't Exists!
            ResultDir.mkdir();
        }
        SimpleDateFormat dateFormat=new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ssaa");
        extent=new ExtentReports(ResultDir +"/" +"Report"+""+dateFormat.format(date)+".html",false);
    }

    public static RemoteWebDriver getInstance()
    {
        return driver;
    }


    @BeforeSuite
    public static void setUp() throws MalformedURLException {
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Xiaomi Redmi Note 4 Android 7.0, API 23");
        cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "4000");
        cap.setCapability("noReset", true);
        cap.setCapability(CapabilityType.VERSION, "7.0 NRD90M");
        cap.setCapability("automationName", cfg.getAutomationName());
/*        cap.setCapability("appPackage",cfg.getAppPackage());
        cap.setCapability("appActivity", cfg.getAppActivity());*/
        cap.setCapability("appPackage",cfg.getAppPackage());
        cap.setCapability("appActivity", cfg.getAppActivity());
        cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "60");

        driver = new AndroidDriver<MobileElement>(new URL(cfg.getApplicationUrl()), cap);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

     /*  int count=3;
       By str = By.id("com.amhi.healthjinn:id/btnNext");
       if(!visibilityOfElement(str))
           System.out.println("Proceed...");
       else{
           for(int i=0;i<count;i++) {
               driver.findElement(By.id("com.amhi.healthjinn:id/btnNext")).click();
           } }*/
    }
}
