package ObjectRepository;

import org.openqa.selenium.By;

public class ContactUsObjects {
    public static By clickOnDropdown1=By.xpath("//*[@class='android.widget.TextView'][@text='Inquiry']");
    public static By waitForValues=By.xpath("//*[@class='android.widget.TextView'][@text='Request']");
    public static By selectDropDownValues=By.xpath("//*[@class='android.widget.TextView']");
   // public static By clickOnDropDown2=By.xpath("//*[@class='android.widget.TextView'][@text='ID Card']");
    public static By clickOnSend=By.id("com.amhi.healthjinn:id/send");
    public static By visibleText=By.xpath("//*[@text='PROCEED']");
    public static By waitOkbtn=By.xpath("//*[@text='OK']");
    public static By clickOnProceedButton=By.xpath("//*[@text='PROCEED']");
    public static By clickOnOkBtn=By.xpath("//*[@text='OK']");
}
