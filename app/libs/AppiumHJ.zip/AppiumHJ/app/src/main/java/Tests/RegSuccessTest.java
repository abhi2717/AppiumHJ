package Tests;

public class RegSuccessTest {
}
