package Tests;

import org.testng.annotations.Test;
import Pages.MoreTab;
import GenericLab.ApplicationHandling;
public class MoreTest extends ApplicationHandling{

    @Test
    public void ConatctUs()
    {
        MoreTab moreTab_obj = new MoreTab();
        moreTab_obj.clickOnContactUS();
    }
}
