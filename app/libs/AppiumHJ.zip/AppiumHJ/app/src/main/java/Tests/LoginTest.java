package Tests;

import org.testng.annotations.Test;

import java.io.IOException;

import DataProvider.DataProviderLoginPage;
import GenericLab.ApplicationHandling;
import Pages.LoginPage;

public class LoginTest extends ApplicationHandling{
    LoginPage loginPage_obj = new LoginPage();

/*    @Test(dataProviderClass= DataProviderLoginPage.class,dataProvider="getTableData")
    public void loginOTP (String email,String expectedmsg)
    {
        //LoginPage loginPage_obj = new LoginPage();
        loginPage_obj.loginViaOTP(email,expectedmsg);
    }*/

/*    @Test(dataProviderClass= DataProviderLoginPage.class,dataProvider= "invalidData")
    public void invalidLoginDetails(String tcId,String tcName,String email,String expectedmsg) throws IOException {
        test=extent.startTest(tcId+" :  "+tcName);
        loginPage_obj.invalidLogin(tcId,tcName,email,expectedmsg);
        extent.endTest(test);
        extent.flush();
    }*/

    @Test(dataProviderClass= DataProviderLoginPage.class,dataProvider= "invalidData")
    public void invalidLoginDetails(String tcId,String tcName,double email,String expectedmsg) throws InterruptedException {
        test=extent.startTest(tcId+" :  "+tcName);
        loginPage_obj.otpLogin(tcId,tcName,email,expectedmsg);
        extent.endTest(test);
        extent.flush();
    }

   /* @Test
    public void loginAccountLocked(){
       // loginPage_obj.accLockedLoginLogout();
    }*/
}

