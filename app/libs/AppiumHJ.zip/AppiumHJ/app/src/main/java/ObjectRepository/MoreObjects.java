package ObjectRepository;

import org.openqa.selenium.By;

public class MoreObjects {
    public static By clickOnMore=By.id("com.amhi.healthjinn:id/more");
    public static By waitForText=By.xpath("//*[@text='My Account']");
    public static By scrollOnMoreTab=By.id("com.amhi.healthjinn:id/scrollView");
    public static By clickContactUs=By.xpath("//*[@text='Contact Us']");

}
