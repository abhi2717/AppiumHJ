package ObjectRepository;

import org.openqa.selenium.By;

public class MyPolicyObjects {

    public static By clickMyPolicy=By.xpath("//*[@text='My Policy']");
    public static By appTitleTxt=By.xpath("//*[@text='My Policies']");

}
