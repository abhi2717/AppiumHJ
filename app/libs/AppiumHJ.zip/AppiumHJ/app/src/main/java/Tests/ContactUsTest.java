package Tests;

import org.testng.annotations.Test;

import Pages.ContactUs;
import GenericLab.ApplicationHandling;
public class ContactUsTest extends ApplicationHandling {

    @Test
    public void Query()
    {
        ContactUs contactUs_obj = new ContactUs();
        contactUs_obj.postQuery();
    }
}
