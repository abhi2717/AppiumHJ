package Pages;

import GenericLab.ActionDrivers;
import ObjectRepository.MyPolicyObjects;

public class MyPolicyPage extends ActionDrivers {

/*public static void verifyMypolicyFields()
{
    LoginPage.loginViaOTP();
    click(MyPolicyObjects.clickMyPolicy);
    expliciltyWait(MyPolicyObjects.appTitleTxt);


}*/

}
