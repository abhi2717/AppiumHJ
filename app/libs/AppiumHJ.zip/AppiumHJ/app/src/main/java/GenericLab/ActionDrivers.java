package GenericLab;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import ObjectRepository.LoginObjects;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class ActionDrivers extends ApplicationHandling{
    //protected AndroidDriver driver;

    /*public ActionDrivers(AndroidDriver driver) {
        this.driver=driver;
    }*/
 /*   public static WebDriverWait wait;
    public static AndroidDriver driver;*/



    public static void click(By loc) {
        //System.out.println(loc);
        WebElement element = driver.findElement(loc);
        element.click();
    }

    public static void type(By loc) {
        WebElement element = driver.findElement(loc);
        element.sendKeys();
    }

    public static String readOTP()
    {
        //driver.startActivity("com.android.mms", "com.android.mms.ui.ConversationList");
        driver.openNotifications();
        String otp = driver.findElementByXPath("//*[contains(@text,'is')]").getText().split("code:" )[0];
        return otp;
    }

    public static void expliciltyWait(By loc){
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(loc));
    }

    public static void openEmail() throws EmailException {

        Email email = new SimpleEmail();
        email.setHostName("smtp.googlemail.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator("username", "password"));
        email.setSSLOnConnect(true);
        email.setFrom("user@gmail.com");
        email.setSubject("TestMail");
        email.setMsg("This is a test mail ... :-)");
        email.addTo("foo@bar.com");
        email.send();

    }
   /* public void waitForPageLoad()
    {
        wait=new WebDriverWait(driver, 40);
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    @Override
                    public Boolean apply(WebDriver webDriver) {
                        return null;
                    }

                    public Boolean apply(AndroidDriver driver) {
                        return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                    }
                };
        wait.until(pageLoadCondition);

    }*/

    public static void scroll(By loc, String val) {
        WebElement list = driver.findElement(loc);
        list.findElement(MobileBy
                .AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                        + "new UiSelector().text(\" val \"));"));
    }

    public static boolean visibilityOfElement(By Loc)
    {
        WebElement element = driver.findElement(Loc);
        element.isDisplayed();
        return true;
    }

    public static String getText(By loc)
    {
        WebElement element = driver.findElement(loc);
        return element.getText();
    }

    public static void getAttribute(By loc, String str)
    {
        WebElement element = driver.findElement(loc);
        element.getAttribute(str);
    }

    public static void clearTextboxField(By loc)
    {
        WebElement element = driver.findElement(loc);
        element.clear();
    }

    public void dropDown(By loc,String text){
        List<AndroidElement> list= driver.findElements(loc);
        for(int i=0; i<list.size();i++){
            WebElement values = list.get(i);
            if(values.getAttribute("text").equalsIgnoreCase(text))
                values.click();
        }
    }

    public static void allowAppPermission() {
        while (driver.findElements(MobileBy.xpath("//*[@class='android.widget.Button'][2]")).size() > 0) {
            driver.findElement(MobileBy.xpath("//*[@class='android.widget.Button'][2]")).click();
        }
    }
}
