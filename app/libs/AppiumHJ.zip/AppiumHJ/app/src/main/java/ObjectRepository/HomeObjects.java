package ObjectRepository;

import org.openqa.selenium.By;

public class HomeObjects {
    public static By clickOnMoreTab=By.xpath("//*[@text='More']");
    public static By waitForText=By.xpath("//*[@text='My Account']");
}
