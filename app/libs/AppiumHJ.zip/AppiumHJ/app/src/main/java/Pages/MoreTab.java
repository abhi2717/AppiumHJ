package Pages;

import GenericLab.ActionDrivers;
import ObjectRepository.MoreObjects;

public class MoreTab extends ActionDrivers {
   // MoreObjects more_obj = new MoreObjects();

    public void clickOnContactUS()
    {
        //action_obj.click(more_obj.clickOnMore);
        scroll(MoreObjects.scrollOnMoreTab,"Contact Us");
        click(MoreObjects.clickContactUs);
    }
}
